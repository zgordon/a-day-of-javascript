		<div class="entry-meta">
			<?php apidemo_posted_on(); ?>
		</div><!-- .entry-meta -->