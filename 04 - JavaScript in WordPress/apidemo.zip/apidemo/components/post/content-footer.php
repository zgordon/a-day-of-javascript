	<footer class="entry-footer">
		<?php apidemo_entry_footer(); ?>
	</footer><!-- .entry-footer -->